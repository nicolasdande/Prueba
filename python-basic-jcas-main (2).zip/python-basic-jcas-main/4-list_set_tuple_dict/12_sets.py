set1 = set()
print(set1)
set1.add("ABC")
set1.add(30)
print(set1)

set1.add('99')
print(set1)

