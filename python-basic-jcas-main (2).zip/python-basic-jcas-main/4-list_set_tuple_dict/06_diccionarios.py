diccionario1 = {
    "Nombre": "Jimmy",
    "Profesion": "Ingeniero",
    "Edad": 25,
}

diccionario2 = dict(Nombre="Jimmy", Profesion="Ingeniero", Edad=25)

print(diccionario1)
print(diccionario2)