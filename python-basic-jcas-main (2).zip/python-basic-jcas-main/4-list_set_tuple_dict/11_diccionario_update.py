dic1 = {'a': 1, 'b': 5, 'c': 4, 'd': 8}
dic2 = {'a': -4, 'x': 20}

print(dic1)
print(dic2)

dic1.update(dic2)

print(dic1)
