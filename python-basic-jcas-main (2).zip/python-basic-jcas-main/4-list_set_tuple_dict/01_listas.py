lista_1 = [1, 2, 3, 4] # Hemos creado una lista de números.
lista_2 = list("1234") # Se puede crear una lista usando list() y pasando un objeto iterable.
lista_3 = [1, "Hola", 3.67, [1, 2, 3]] # Pueden almacenar tipos de datos distintos
print(lista_1) 
print(lista_2) 
print(lista_3) 
print(lista_3[0])
print(lista_3[1]) 
print(lista_3[-1])
print(len(lista_3))
