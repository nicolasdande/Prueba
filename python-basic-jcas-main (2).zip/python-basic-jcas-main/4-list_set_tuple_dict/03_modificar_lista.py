lista = [1, 2, 3, 4, 8, 10, '45']
print(lista)  #[1, 2, 3, 4, 8, 10, '45']
lista[2] = 'Lunes'
print(lista)  #[1, 2, 'Lunes', 4, 8, 10, '45']