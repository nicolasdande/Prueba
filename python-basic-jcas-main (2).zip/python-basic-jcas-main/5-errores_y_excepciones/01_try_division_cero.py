try:
    a = 4
    b = 0
    print(a/b)
except:
    print("Ha ocurrido un error")

print("El pgorgrama ha finalizado")
