# python-basic-jcas
Basic Python exercises and material
This repository contains execises and documentation related to Python and is intended to help learn to code in Python.
It is organized in levels so any person can go gradually exploring at his/her own pace
