texto = "Agua pasada no vuelve al molino"

#str[inicio:final:saltos]
print(texto[:])
print(texto[3:])
print(texto[5:11]) #recordemos que end, nos devuelve end-1