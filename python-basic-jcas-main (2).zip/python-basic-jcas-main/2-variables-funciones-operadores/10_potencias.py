#2 elevado a la 5, 10 elevado a la 3, 14 elevado a la 2.

print("2 elevado a la 5 = {}".format(2**5))

print("10 elevado a la 3 = {}".format(10**3))

print("14 elevado a la 2 = {}".format(14**2))
