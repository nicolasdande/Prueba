texto_1 = "Hoy es junio 7"
texto_a_buscar_1 = "es" 
texto_a_buscar_2 = "Hola"

print(texto_a_buscar_1 in texto_1)
print(texto_a_buscar_2 in texto_1)