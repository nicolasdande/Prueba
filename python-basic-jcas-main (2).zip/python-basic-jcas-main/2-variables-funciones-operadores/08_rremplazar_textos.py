texto = "Hoy es lunes"
print(texto)
texto_a_reemplazar = "lunes"
texto_unevo = "Martes"
reemplazo = texto.replace(texto_a_reemplazar, texto_unevo)
print(reemplazo)