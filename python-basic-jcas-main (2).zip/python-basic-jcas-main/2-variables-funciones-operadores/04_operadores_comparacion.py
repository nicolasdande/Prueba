a = 5
b = 5

print(a is b)
print(a is not b)