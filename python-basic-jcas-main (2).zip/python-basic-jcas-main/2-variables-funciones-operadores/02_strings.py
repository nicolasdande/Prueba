texto = "Hola Python"

print(len(texto))
print(texto[3])
print(texto[-10])
print(texto[10])