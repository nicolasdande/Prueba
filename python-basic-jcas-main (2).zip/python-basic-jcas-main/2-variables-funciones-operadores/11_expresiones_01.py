resultado = (1 == 1) and (2 > 1)
print("El resultado de (1 == 1) and (2 > 1) es:", resultado)

resultado_1 = (0 != 0) and (10 > 20)
print("El resultado de (0 != 0) and (10 > 20) es:", resultado_1)

resultado_2 = (10 > 20) or (3 == 3)
print("El resultado de (10 > 20) or (3 == 3) es:", resultado_2)

resultado_3 = (3 == 3) or (10 > 20)
print("El resultado de (3 == 3) or (10 > 20) es:", resultado_3)

resultado_4 = not (30 > 20)
print("El resultado de 'not (30 > 20)' es:", resultado_4)

