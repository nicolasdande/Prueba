archivo = open("01_operaciones_archivos_2.txt", "x")
archivo.write("Otra linea de codigo")
archivo.close()