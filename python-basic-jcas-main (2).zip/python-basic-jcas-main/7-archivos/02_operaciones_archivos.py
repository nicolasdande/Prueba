with open("01_operaciones_archivos.txt", "r") as archivo:
    for linea in archivo:
        print(linea)