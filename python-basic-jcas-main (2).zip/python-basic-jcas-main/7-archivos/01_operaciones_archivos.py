#with open("tema_7_archivos/01_operaciones_archivos.txt") as archivo:
with open("01_operaciones_archivos.txt") as archivo:
    contenido = archivo.read()
    print(contenido)
