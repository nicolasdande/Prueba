numero =  10
i = 0
while i < numero:
    print(i)
    i += 2 # i = i + 1

print("El while ha terminado")