#operador ternario
hora = 5
saludo = "buenos dias" if hora < 12 else "buenas tardes"
print(saludo)


if hora < 12:
    saludo_if = "buenos dias"
else:
    saludo_if = "buenos tardes"

print(saludo_if)