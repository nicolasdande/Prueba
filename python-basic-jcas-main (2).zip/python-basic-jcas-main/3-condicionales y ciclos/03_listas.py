lista_1 = [1, 2, 3, 4, 100]
print(lista_1)
print(lista_1[2])
print(lista_1[-1])
print(lista_1[:3])