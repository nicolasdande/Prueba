for numero in range(10):
    print(numero)

for numero in range(10, 21):
    print(numero)

for numero in range(10, 21, 3):
    print(numero)