
numero = 2
if numero == 0:
    #todo el codigo as partir de aqui, pertenece al if (if numero == 0)
    print("Numero igual a cero")
elif numero <= 5:
    if numero == 2:
        print("Numero igual a dos")
    else:
        print("Numero menor que 5")
else:
    print("Numero diferente a cero")
