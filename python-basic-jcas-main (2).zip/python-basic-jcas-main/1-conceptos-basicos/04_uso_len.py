curso = "Curso de Python"
longitud = len(curso)
print("La longitud de la variables es:", longitud)