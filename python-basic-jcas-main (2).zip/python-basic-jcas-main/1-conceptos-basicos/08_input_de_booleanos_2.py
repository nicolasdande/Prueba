variable_a = input("Ingrese SI o NO segun su eleccion:")
valor_booleano = bool(variable_a == 'SI')
print("valor_booleano es =", valor_booleano)

#SI ES UNA STRING, SOLO SEDRIA FALSE SI ESTA VACIA.
#SI ES UN VALOR NUMERICO (INT O FLOAT) SOLO ES FALSE SI ES IGUAL A 0
print("Hola", "mundo", sep=" \U0001F600 ")