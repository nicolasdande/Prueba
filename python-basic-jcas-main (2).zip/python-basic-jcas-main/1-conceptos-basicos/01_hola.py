'''
Este es un comentario de
varias lineas
Tres lineas como ejemplo
'''
print("Hola Pythonistas")
saludo = "Buenos dias"
nombre = "Pedro"

#PRINT DE VARIOS VALORES O VARIABLES
print(saludo, nombre, "Como estas?")

#PRINT CON SEPARADOR ENTRE VARIABLES O VALORES
print(saludo, nombre, "Como estas?", sep="-")

#VARIABLE nombre, e imprimirla
nombre = "Jimmy"
print(nombre)

mi_dato = 2001
print("Mi dato es:", mi_dato)