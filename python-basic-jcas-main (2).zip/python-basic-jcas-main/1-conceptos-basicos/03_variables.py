result = 10 * 3.0
print("La variables result es de tipo:", type(result))
print("El valor de la variable result es:", result)
