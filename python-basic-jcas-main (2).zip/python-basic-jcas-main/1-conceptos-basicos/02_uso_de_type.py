cadena = 'Hola curso, saludos'
#print(type(cadena))

print(type('True'))

print(type(True))