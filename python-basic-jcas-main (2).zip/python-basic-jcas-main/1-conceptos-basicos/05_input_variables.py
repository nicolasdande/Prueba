nombre = input("Ingresa tu nombre:")
edad = input('Ingresa tu edad:')
deporte = input("Qué deporte te gusta:")

salida = "Hola " + nombre + " tienes " + edad + " años, y te gusta el " + deporte
print(salida)
print("Hola", nombre, "tienes", edad, "años, y te gusta el", deporte)
