variable_a = input("Ingrese el dato:")
#valor_booleano = bool(variable_a)
valor_booleano = bool(int(variable_a))
print("valor_booleano es =", valor_booleano)

#SI ES UNA STRING, SOLO SEDRIA FALSE SI ESTA VACIA.
#SI ES UN VALOR NUMERICO (INT O FLOAT) SOLO ES FALSE SI ES IGUAL A 0