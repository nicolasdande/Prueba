numero_a = int(input("Ingrese primer numero:"))
numero_b = input('Ingrese segundo numero:')

num_convertido = int(numero_b)

resultado = min(numero_a,num_convertido)
print("El numero menor es:", resultado)
