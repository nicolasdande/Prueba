a = 5
b = 10
resultado = a + b
print(resultado)