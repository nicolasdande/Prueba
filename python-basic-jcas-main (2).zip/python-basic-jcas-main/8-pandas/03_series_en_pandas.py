# Recuerda instalar pandas: pip install pandas
import pandas as pd

# Crear una Serie
serie = pd.Series([10, 20, 30, 40, 50])

# Crear una Serie
serie_nombres = pd.Series(["Carlos", "Pedro", "Maria", "Rosa"])

print(serie)

print(serie_nombres)

